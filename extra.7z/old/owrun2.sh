./xmrig -o pool.supportxmr.com:443 -u 41oXNwxNK9hAcHNGkRkSGmPxCnfpNX9TUiaQc6w6FvwrJp1UHfiEoaAU1bXr8Vj4DR6Ubi9qNEhfieU9eTzy3S3sMAzbmrN -k --tls -p OnWorks
