---
title: changelog
---

# 站点更新日志

> 2023/10/20：
> 
> - Keep主题更新至3.8.5
> 
> - 移除底部的APlayer音乐播放器
> 
> - 页底部署行仅保留Cloudflare
> 
> - 缩小异次元之旅图标至13px
> 
> - 移除异次元之旅和萌ICP备之间的“|”号

> 2023/10/01：
> 
> ● 更改欢迎弹窗内容，新增教程跳转链接
> 
> ● 更改公告内容
> 
> ● 更改文章 hexoaddsweetalert2 （复制搜索此代号浏览此文章）中的一处弹窗示例代码
> 
> ● 将Email点击动作由直接跳转mailto链接修改为弹出弹窗
> 
> ● 修改页脚文字“主题 Keep v3.7.7”为“基于 Keep v3.7.7 修改”
> 
> ● 页脚页面部署提供商新增Cloudflare，跳转链接改为站内
> 
> ● 新增页面“部署”（隐藏），点击页脚”本站由......提供部署服务“行即可跳转
> 
> ● 联系方式移除Twitter / X

> 2023/09/24：新增欢迎弹窗

> 2023/09/24：将站点的所有[cdn.jsdelivr.net](https://cdn.jsdelivr.com)和[unpkg.com](https://unpkg.com)请求分别移至自搭镜像站

> 2023/09/23：将主站搬迁至Cloudflare Pages，原Github Page站点搬迁至[https://gh.xtzyj.top](https://gh.xtzyj.top)

> 2023/09/16：[直播]支持发送弹幕，为iOS用户添加了hls.js拉流协议

# 公告栏更新日志

> 2023/09/28-2023/10/01：本站已迁移至Cloudflare，原GitHub Page站点：[gh.xtzyj.top](https://gh.xtzyj.top)
