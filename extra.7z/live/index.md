---
title: HTTP-FLV直播
---

# 🎥直播画面

[点击进入直播网页](http://ddns.ganshity.top:51200)（iOS以外平台观看，flv.js延迟大约2秒）

报ERR_CONNECTION_REFUSED就是没开播，开播时下进去可以看到DPlayer页面

iOS用户[点击此处](http://ddns.ganshity.top:51200/hls)观看（hls.js延迟大约30秒）

点击[这里](https://xtzyj.top/2023/09/16/%E8%87%AA%E5%B7%B1%E6%90%AD%E5%BB%BA%E7%9B%B4%E6%92%AD%E5%B9%B3%E5%8F%B0%EF%BC%8C%E4%BD%BF%E7%94%A8Nginx-RTMP-HTTPFLV%EF%BC%8CDPlayer%E6%92%AD%E6%94%BE/)查看直播搭建教程

### 更改日志

2023/09/16：支持发送弹幕，为iOS用户添加了hls.js拉流协议
